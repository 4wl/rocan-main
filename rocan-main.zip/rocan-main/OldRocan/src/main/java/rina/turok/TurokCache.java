package rina.turok;

/**
  *
  * @author Rina!
  *
  * Created by Rina!
  * 17/08/2020.
  *
  **/
public class TurokCache {
	private String cache;

	public TurokCache(String cache) {
		this.cache = cache;
	}

	public void setCache(String cache) {
		this.cache = cache;
	}

	public String getCache() {
		return this.cache;
	}
}