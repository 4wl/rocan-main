package rina.rocan.event.player;

// Event.
import rina.rocan.event.RocanEventCancellable;

/**
  *
  * @author Rina!
  *
  * Created by Rina!
  * 25/08/2020.
  *
  **/
public class RocanEventPlayerUpdateWalking extends RocanEventCancellable {
	public RocanEventPlayerUpdateWalking(EventStage stage) {
		super(stage);
	}
}
