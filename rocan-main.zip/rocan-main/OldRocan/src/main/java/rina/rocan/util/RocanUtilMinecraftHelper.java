package rina.rocan.util;

// Minecraft.
import net.minecraft.client.Minecraft;

// Rocan.
import rina.rocan.Rocan;

/**
 *
 * @author Rina!
 *
 * Created by Rina!
 * 17/08/2020.
 *
 **/
public class RocanUtilMinecraftHelper {
	public static Minecraft getMinecraft() {
		return Minecraft.getMinecraft();
	}
}