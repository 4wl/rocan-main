package rina.rocan.client;

/**
  *
  * @author Rina!
  *
  * Created by Rina!
  * 09/09/2020.
  *
  **/
public class RocanFriend {
	private String name;

	public RocanFriend(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}
}