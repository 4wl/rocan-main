package rina.rocan.client;

/**
  *
  * @author Rina!
  *
  * Created by Rina!
  * 11/09/2020.
  *
  **/
public class RocanEnemy {
	private String name;

	public RocanEnemy(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}
}