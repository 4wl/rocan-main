package me.rina.rocan.api.module.impl;

/**
 * @author SrRina
 * @since 15/11/20 at 4:51pm
 */
public enum ModuleCategory {
    Combat, Client;
}