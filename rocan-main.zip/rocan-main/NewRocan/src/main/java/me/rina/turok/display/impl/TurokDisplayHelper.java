package me.rina.turok.display.impl;

public interface TurokDisplayHelper {
    public void onSyncSize(int screenWidth, int screenHeight, int scaledWidth, int scaledHeight);
}
