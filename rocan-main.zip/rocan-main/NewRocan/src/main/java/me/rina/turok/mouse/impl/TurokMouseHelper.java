package me.rina.turok.mouse.impl;

/**
 * @author Rina.
 * @since 02/10/2020.
 **/
public interface TurokMouseHelper {
    public void onSyncPosition(int mx, int my);
    public void onSyncScroll(int scroll);
}
