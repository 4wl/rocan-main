package me.rina.rocan.api.event.impl;

/**
 * @author SrRina
 * @since 15/11/20 at 7:45pm
 */
public enum EventStage {
    Pre, Post;
}